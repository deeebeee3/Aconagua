var Tool = require('./tool')
require('./modifications')
require('./verifications')
require('./generate-jsdoc')
module.exports = Tool