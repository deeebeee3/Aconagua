// var suitetalk = require('../src/index'); 
// var _ = require('underscore'); 

// var testUtil = require('./testUtil'); 
  
// describe('search templates', function()
// {
// 	var pageSize = 6; 

// 	// it('searchBasic template', function(cb)
// 	// {

// 	// 	var searchCommand1 = {
// 	// 		recordType: 'folder'
// 	// 	,	filters: {
// 	// 			parent: {
// 	// 				type: 'SearchMultiSelectField'
// 	// 			,	operator: 'anyOf'
// 	// 			,	searchValue: [{
// 	// 					type: 'RecordRef'
// 	// 					, internalId: '11689'
// 	// 				}]
// 	// 			}
// 	// 		}
// 	// 	}; 
// 	// 	var output = suitetalk._template('searchBasic.tpl', searchCommand1); 
// 	// 	// console.log(output); 

// 	// 	cb();
// 	// }); 

// 	it('deleteList template', function(cb)
// 	{
// 		var deleteListCommand1 = {
// 			records: [
// 				{recordType: 'file', internalId: '123'}
// 			,	{recordType: 'folder', internalId: '234'}
// 			]
// 		}; 
// 		var output = suitetalk._template('deleteList.tpl', deleteListCommand1); 
// 		console.log(output); 

// 		cb();
// 	}); 

// }); 




